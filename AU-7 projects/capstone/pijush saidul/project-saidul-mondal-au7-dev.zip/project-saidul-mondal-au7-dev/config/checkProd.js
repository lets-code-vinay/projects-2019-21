const isProduction = process.env.NODE_ENV === 'production' ? true : false;
exports.isProduction = isProduction;