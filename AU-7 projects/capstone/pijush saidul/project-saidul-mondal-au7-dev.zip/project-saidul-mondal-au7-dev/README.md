Backend application run - npm run dev

Backend application test - npm run cover

Backend deployment link - https://tution-media.herokuapp.com/