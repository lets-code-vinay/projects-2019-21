export default {
  port: process.env.PORT || 5000,
};
