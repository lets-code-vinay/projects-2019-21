export default {
  MONGOURI: process.env.MONGOURI,
  JWT_KEY: process.env.JWT_KEY,
};
