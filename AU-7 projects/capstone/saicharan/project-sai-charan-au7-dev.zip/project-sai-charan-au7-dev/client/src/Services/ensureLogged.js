import React from "react";

function ensureLogged() {
  return <div></div>;
}

export default ensureLogged;
