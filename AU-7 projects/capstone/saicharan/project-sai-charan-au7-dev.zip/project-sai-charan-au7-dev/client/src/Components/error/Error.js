import React from 'react'
import error from "./e.svg"
import {Link} from "react-router-dom"

function Error() {
    
    return (
        <div>
            <img src={error} style={{height:"75vh"}}></img>
            
            
        </div>
    )
}

export default Error
