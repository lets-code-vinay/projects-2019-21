import React from "react";

const MedTitle = () => {
  return (
    <>
      <div id="medcamp">
        <div className="container text-center">
          <h2 className="py-3">Medical Camps</h2>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure sint
            ad iusto cumque numquam in!
          </p>
        </div>
      </div>
    </>
  );
};

export default MedTitle;
