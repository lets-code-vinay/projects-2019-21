import React from "react";

const ContTitle = () => {
  return (
    <>
      <div className="section-title text-center mt-5">
        <h2>Contact</h2>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam,
          accusamus.
        </p>
      </div>
    </>
  );
};

export default ContTitle;
