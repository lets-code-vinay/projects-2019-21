import React from "react";
import PaitentDataBtn from "../user/Paitent";

const AppoCom = () => {
  return (
    <>
      <PaitentDataBtn />
    </>
  );
};

export default AppoCom;
