import React from "react";

const Copy = () => {
  return (
    <>
      <div className="col-lg-4 text-lg-left">
        Copyright © InfoMiniByte Technologies 2020
      </div>
    </>
  );
};

export default Copy;
