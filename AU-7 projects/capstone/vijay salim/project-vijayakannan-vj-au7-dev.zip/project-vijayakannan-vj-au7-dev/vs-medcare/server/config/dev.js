module.exports = {
  mongourl: process.env.MONGO_URL,
};
