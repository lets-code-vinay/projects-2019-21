import React from "react";
import "./eachproduct.css";

function Eachproduct() {
  return <div className="eachproduct">Eachproduct</div>;
}

export default Eachproduct;
