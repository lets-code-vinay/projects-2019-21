import React,{useState} from 'react';
import Layout from '../core/Layout';
import {signin,authenticate,isAuthenticate } from '../auth'
import { Redirect,Link} from 'react-router-dom';
           
const Signin = () => {

    const [values,setValues] = useState({
        email: 'rashie2012@gmail.com',
        password: 'Asd@123',
        error: '',
        loading: false,
        redirectToReferrer:false 
    });

    const {email,password,loading,error,redirectToReferrer} = values
    const {user} = isAuthenticate();
    const handleChange = email => event =>{
        setValues({...values,error:false,[email]: event.target.value });
    };

    const clickSubmit = (event) =>{
        event.preventDefault()
        setValues({...values, error: false, loading:true})
        signin({email,password})
        .then(data => {
            if(data.error){
                setValues({...values,error:data.error, loading:false})
            }else {
               authenticate(data, () => {
                setValues({
                    ...values,
                
                    redirectToReferrer: true 
                });
               }); 
            }
        })
    }

    const signInForm = () => ( 
        <div class="card mx-auto" >
            <article class="card-body">
                <header class="mb-4"><h4 class="card-title">SignIn</h4></header>
                <form> 
                    <div>
                        <label style={{color:'black'}}>Email</label>
                        <input onChange={handleChange('email')} type="email" name="email" class="form-control" value={email}></input>
                    </div>
                    <br>
                    </br>
                    <div class="form-row">
                        <div class="col form-group ">
                            <label style={{color:'black'}}>Password</label>
                            <input onChange={handleChange('password')} class="form-control" name ="password" type="password" value={password} />
                        </div>
                    </div>
                    <div class="form-group">
                        <button onClick={clickSubmit} type="submit" class="btn btn-primary btn-block"> Login  </button>
                    </div>  
                </form>
            </article>
        </div> 
    );
    const showErr= () => (
        <div className = "alert alert-danger" style={{display: error? '' : 'none'}}>
            {error}
        </div>
    )

    const showLoading= () =>(
        loading && <div className = "alert alert-info" >
            <h2>
                loading...
            </h2>
        </div>
    );

    const redirectUser = () => {
        if(redirectToReferrer){
           if(user && user.usertype === 0){
                return <Redirect to="/seller" />
           }else if(user && user.usertype === 1){
                return <Redirect to="/" />
           }

        }
    }
    const signupLink= ()=>{
        return( 
            <div style={{color:"#1b6356",textAlign:"center"}}> New user? Click
            <Link to="/register" style={{color:"#e60e8a"}}> here </Link> to signup.
        </div>)
    }

    const forgotpwd =()=>{
        return(
            <div style={{textAlign:"center"}} >
            <Link to="/frgtpwd" style={{color:"#ee3955"}}> Forgot password?? </Link> 
        </div>)
        
    }
    return (
        <div className="container col-md-6 offset-md-3 mt-3">
            {showErr()}
            {showLoading()}
            {signInForm()}
            {redirectUser()}
            {signupLink()}
            <br/>
            {forgotpwd()}

        </div>
    );   
};

export default Signin;