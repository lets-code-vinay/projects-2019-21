import React from 'react';

const App = ()=> 
  <div>
    heloo
  </div>
export default App;

