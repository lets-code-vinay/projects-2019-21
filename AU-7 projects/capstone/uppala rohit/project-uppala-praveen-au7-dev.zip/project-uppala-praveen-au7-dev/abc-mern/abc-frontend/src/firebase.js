const firebaseConfig = {
    apiKey: "AIzaSyCSmBJkfrrTGdihZoxGQu9myDNodK6FyY8",
    authDomain: "abc-235bc.firebaseapp.com",
    databaseURL: "https://abc-235bc.firebaseio.com",
    projectId: "abc-235bc",
    storageBucket: "abc-235bc.appspot.com",
    messagingSenderId: "1005158141315",
    appId: "1:1005158141315:web:b37a8d336b50fc96113ab6"
  };