// const path = require('path')

// console.log(path.join(__dirname,'chat-app-front'))
// const pc = new RTCPeerConnection()
// console.log(RT)