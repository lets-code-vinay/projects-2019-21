import React from 'react'
import classes from "./create_room.module.css"

const create_room = (props) => {
    return (
        <button className={classes.create_room} type="button" >Create-Room</button>
    )
}

export default create_room