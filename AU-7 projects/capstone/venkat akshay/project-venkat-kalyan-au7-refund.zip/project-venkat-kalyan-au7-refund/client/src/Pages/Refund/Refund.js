import React from 'react'

function Refunded() {
    return (
        <div style={{maxWidth: '85%', margin: '2rem auto'}}>
            <div style={{ textAlign: 'center', fontStyle: 'italic'}}>
                <h2>Thank you for using our services</h2>
                <h2>Visit again</h2>
            </div>
        </div>
    )
}

export default Refunded