module.exports = {
    mongoURI:'mongodb+srv://kalyan:billdesk@cluster0.6wcwx.mongodb.net/billdeskdb?retryWrites=true&w=majority',
    secretKey:'somesecret'
}