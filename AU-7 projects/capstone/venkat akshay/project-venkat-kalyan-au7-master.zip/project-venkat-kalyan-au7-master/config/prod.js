module.exports = {
    mongoURI:process.env.mongoURI,
    secretKey: process.env.secretKey
}