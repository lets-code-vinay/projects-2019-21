import React from 'react'

function Refunded() {
    return (
        <div style={{maxWidth: '85%', margin: '2rem auto'}}>
            <div style={{ textAlign: 'center', fontStyle: 'italic'}}>
                <h2>Transaction Refunded</h2>
                <h2>Check Transactions Page</h2>
            </div>
        </div>
    )
}

export default Refunded