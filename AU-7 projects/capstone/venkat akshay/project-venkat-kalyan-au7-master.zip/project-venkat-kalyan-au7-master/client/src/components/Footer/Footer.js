import React from 'react'
// import {Icon} from 'antd';
import { CopyrightCircleFilled } from '@ant-design/icons';

import './Footer.css'
function Footer() {
    return (
        <div className='footer'>
           <p>  BILL DESK <CopyrightCircleFilled /> @2020</p>
        </div>
    )
}

export default Footer
