export const USER_LOGIN = 'user_login';
export const USER_AUTH = 'user_auth';
export const USER_LOGOUT = 'user_logout';

export const BOOK_ADD = 'book_add';
export const BOOK_CLEAR = 'book_clear';
export const BOOK_GET = 'book_get';
export const BOOK_UPDATE = 'book_update';
export const BOOKS_GET = 'books_get';