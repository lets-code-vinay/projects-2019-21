import React from 'react';

const AdminLayout = (props) => (
    <div className="container admin_layout">
        <>
            {props.children}
        </>
    </div>
)

export default AdminLayout;