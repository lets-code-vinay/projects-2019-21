export const SET_TAB = "@@tab-id/set";
