export const SET_NOTIFICATION = "@@notification/set";
export const CLEAR_NOTIFICATION = "@@notification/clear";
