export const SET_VALUE = "@@tabs/value";
