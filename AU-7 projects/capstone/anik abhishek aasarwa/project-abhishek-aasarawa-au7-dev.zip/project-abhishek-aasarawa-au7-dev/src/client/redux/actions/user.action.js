export const SET_USER = "@@user/set";
export const CLEAR_USER = "@@user/clear";
