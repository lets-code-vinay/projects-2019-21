export const signin = "@@user/signin";
export const signup = "@@user/signup";
export const forget = "@@user/forget";
export const signout = "@@user/signout";
export const profile = "@@user/profile";
export const share = "@@user/share";
