import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  parent: {
    width: "90.5vw",
    position: "relative",
  },
}));

export default useStyles;
