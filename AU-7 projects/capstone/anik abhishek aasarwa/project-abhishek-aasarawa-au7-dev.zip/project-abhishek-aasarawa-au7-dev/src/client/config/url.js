import dotenv from "dotenv";
dotenv.config();

export default process.env.REACT_APP_URL;
