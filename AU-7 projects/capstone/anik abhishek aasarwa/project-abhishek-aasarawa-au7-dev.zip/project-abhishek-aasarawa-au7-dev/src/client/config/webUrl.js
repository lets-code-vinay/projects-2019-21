export const aboutUs = "/";
export const create = "/create";
export const shared = "/shared";
export const all = "/all";
export const search = "/search";
