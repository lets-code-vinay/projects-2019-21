const { API } = require("../src/config")

 API = `https://quick-mart-app.herokuapp.com`||`http://localhost:8000/api`
module.exports =API