export const prices = [
    {
        _id: 0,
        name: "Any",
        array: []
    },
    {
        _id: 1,
        name: "$100 to $500",
        array: [100, 500]
    },
    {
        _id: 2,
        name: "$500 to $1000",
        array: [500, 1000]
    },
    {
        _id: 3,
        name: "$1000 to $1500",
        array: [1000, 1500]
    },
    {
        _id: 4,
        name: "$1500 to $2000",
        array: [1500, 2000]
    },
    {
        _id: 5,
        name: "More than $2000",
        array: [2000, 10000]
    }
];
