import React from 'react'

const AdminRouting = (props) => {
    console.log('AdminRouting',props)
    return (
        <div>
            <h1>dd</h1>
        </div>
    )
}

export default AdminRouting
