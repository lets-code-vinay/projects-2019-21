import Layout from '../components/Layout';

const Login = () => <Layout>login page</Layout>;

export default Login;
