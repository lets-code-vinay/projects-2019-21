import React from 'react';

function About(){
    return(
        <div>
            <h4>About us</h4>
            <p></p>
        </div>
    )
}

export default About;