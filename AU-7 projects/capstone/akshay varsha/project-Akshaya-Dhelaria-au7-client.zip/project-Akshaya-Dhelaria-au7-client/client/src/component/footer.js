import React from 'react';

function Footer(){
    return(
        <div>
            <p className="footer">Coding Hunt
                <i className="fa fa-copyright"></i>
            </p>
        </div>
    )
}

export default Footer;