import Layout from '../components/Layout';

const Home = () => <Layout>hello next</Layout>;

export default Home;
