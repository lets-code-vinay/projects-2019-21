import Layout from '../../components/Layout';

const Admin = () => <Layout>hello Admin</Layout>;

export default Admin;

