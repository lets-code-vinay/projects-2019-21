import Layout from '../../components/Layout';

const User = () => <Layout>hello User</Layout>;

export default User;
