const Backend_URL = 'https://protected-journey-53561.herokuapp.com/api/v1'

export default Backend_URL
