import Layout from '../components/Layout';

const Home = () => <Layout>hello</Layout>;

export default Home;
