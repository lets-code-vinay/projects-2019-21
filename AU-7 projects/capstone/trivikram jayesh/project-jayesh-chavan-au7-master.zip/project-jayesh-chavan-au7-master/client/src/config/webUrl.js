export default {
    HOME : '/',
    VOLUNTEER_REGISTER : '/volunteer-signup',
    VOLUNTEER_DASHBOARD : '/volunteer-dashboard',
    BLOOD_BANK_REGISTER : '/bloodbank-signup',
    BLODD_BANK_DASHBOARD : '/bloodbank-dashboard',
    LOGIN : '/login',
    Donate : '/donate',
    BloodBankSearch : '/bloodbank-search',
    VolunteerSearch : '/volunteer-search',
    Organise : '/organise',
    EmergencyNotification : '/emergency'
}