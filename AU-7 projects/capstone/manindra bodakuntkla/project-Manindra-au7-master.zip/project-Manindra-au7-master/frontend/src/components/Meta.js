import React from "react";
import { Helmet } from "react-helmet";

const Meta = ({ title, description, keywords }) => {
  return (
    <Helmet>
      <title>{title}</title>
      <meta name='description' content={description} />
      <meta name='keyword' content={keywords} />
    </Helmet>
  );
};

Meta.defaultProps = {
  title: "WELCOME TO FLINN",
  description: "WE ARE VERY EXCITED TO SEE YOU",
  keywords: "electronics",
};

export default Meta;
