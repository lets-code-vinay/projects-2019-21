import React from "react";

const Login = () => {
  return (
    <>
      <h1>Login PAge</h1>
      <p>Welcome to Login PAge</p>
    </>
  );
};

export default Login;
