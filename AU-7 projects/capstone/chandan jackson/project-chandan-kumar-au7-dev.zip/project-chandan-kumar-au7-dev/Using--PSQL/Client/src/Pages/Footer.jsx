import React from "react";

function Footer() {
  return (
    <>
      <footer style={{ marginTop: "100vh" }} className="page-footer">
        <div className="footer-copyright">
          <div className="container">© 2020 Copyright To CK...</div>
        </div>
      </footer>
    </>
  );
}

export default Footer;
