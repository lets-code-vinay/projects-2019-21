import React from "react";

const Register = () => {
  return (
    <>
      <h1>Register Page</h1>
      <p>Welcome to register page</p>
    </>
  );
};

export default Register;
