Easy_Money --------- >>>>>>>>>> https://robin-frontend-project.netlify.app/

Description: A web app where one can apply for a short term loan.

WHY : Because one day my partner Jackson was talking about some app, where he could ask money for short term loan , than we thought to understand , how these app works in real world, so we decided to do this project for understanding more about this , and for practicing all functionality what we had taught in the class ,

Features:
We have a user panel where user related routes will be called .
USER will be able to login or register
User can request a Forgot Password , for that he will receive an email to verify if the request is done by him .
We have a loan amount calculator where the user can find his emi according to his needed amount .
There is an Admin panel as well where admin related requests will be handled like new admin approval. , getting track of who asked for loan , whose payment is due , which admin request is pending ,
User can Apply for loan
He can also be an investor inside our app , where he will have to share more details about himself.
Check for loan application status
User with accepted loan will be able to view their dashboard to check her/his principal, interest amount, tenure of loan etc
ADMIN will be able to either reject or accept loan applications for users after credit check.
View gross disbursed principal and check the interest received from users.
Check whether a user has missed a payment.

Tech stack:
React
Babel inside backend for complete es6 or further feature use
MongoDB
Node JS
JWT,
Jwt-decode inside react
Express JS
axios
multer
Redux
Nodemailer
Cloudinary

Issues: yeah we also faced a lot of issues like component was not rerendering some time , store had data but we were unable to use inside our other pages , faced problem while separating user and admin panel , and a lot more , we used google for resolving this , asked from our mentor and friends ,

Improvement : we are trying to add live chat functionality so that user can talk about his query and get solution for his any type of issue ,

We will be working to enhance user experience at our app..
