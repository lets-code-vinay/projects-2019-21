import React from "react";
// import { Link } from "react-router-dom";

function Footer() {
  return (
    <>
      <div className='wrapper'>
        <footer className='main-footer'>
          <strong>
            &copy; Copyright 2020
            <a
              href='https://www.facebook.com/profile.php?id=100030287472330'
              target='_'>
              Ck...
            </a>
          </strong>
          All rights reserved.
        </footer>
      </div>
    </>
  );
}

export default Footer;
