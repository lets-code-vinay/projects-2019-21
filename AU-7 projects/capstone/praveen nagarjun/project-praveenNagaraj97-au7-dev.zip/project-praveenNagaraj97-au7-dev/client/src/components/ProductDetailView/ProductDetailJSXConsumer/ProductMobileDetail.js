import React from "react";
import ProductCommonJSXConsumer from "./ProductCommonJSXConsumer";

export default () => <ProductCommonJSXConsumer productReviewFor={"mobiles"} />;
