import React from "react";

const DevelopersTab = () => {
  return <h1 style={{ color: "white" }}>DevelopersTab</h1>;
};

export default DevelopersTab;
