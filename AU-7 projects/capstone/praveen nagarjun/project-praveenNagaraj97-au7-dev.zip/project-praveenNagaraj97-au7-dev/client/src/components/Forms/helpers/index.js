export { ProductMobileReview } from "./ProductMobileReviewFields";
export { ProductComputerReview } from "./ProductComputerReview";
export { ProductElectronicsReview } from "./ProductElectronicsReview";
export { ProductBeautyReview } from "./ProductBeautyReview";
export { ProductFashionReview } from "./ProductFashionReview";
export { ProductKitchenReview } from "./ProductKitchenReview";
export { ProductPetReview } from "./ProductPetReview";
export { ProductFoodReview } from "./productFoodReview";
