import ProductMobileDetail from "./ProductDetailJSXConsumer/ProductMobileDetail";
import ProductComputersDetail from "./ProductDetailJSXConsumer/ProductComputersDetail";
import ProductElectronicsDetail from "./ProductDetailJSXConsumer/ProductElectronicsDetail";
import ProductBeautyDetail from "./ProductDetailJSXConsumer/ProductBeautyDetail";
import ProductPetDetail from "./ProductDetailJSXConsumer/ProductPetDetail";
import ProductsFashion from "./ProductDetailJSXConsumer/ProductsFashion";
import ProductKitchen from "./ProductDetailJSXConsumer/ProductKitchen";
import ProductFood from "./ProductDetailJSXConsumer/ProductFood";

export {
  ProductMobileDetail,
  ProductComputersDetail,
  ProductElectronicsDetail,
  ProductBeautyDetail,
  ProductPetDetail,
  ProductsFashion,
  ProductKitchen,
  ProductFood,
};
