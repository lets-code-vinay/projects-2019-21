import React from "react";

// Main Categories of Products!
import HomePage from "../Home";

const Home = () => {
  return (
    <>
      <HomePage />
    </>
  );
};

export default Home;
