import React from "react";

const Loader = () => <div className='loading-spinner'></div>;

export default Loader;
