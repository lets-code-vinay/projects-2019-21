import React from "react";

const BlogAboutProduct = () => {
  return <h1>BlogAboutProduct</h1>;
};

export default BlogAboutProduct;
