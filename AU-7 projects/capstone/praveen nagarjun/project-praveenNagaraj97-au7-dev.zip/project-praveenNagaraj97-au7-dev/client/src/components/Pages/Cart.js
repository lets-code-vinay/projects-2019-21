import React from "react";
import ProductCart from "../Product/ProductCart";

const Cart = () => {
  return <ProductCart />;
};

export default Cart;
