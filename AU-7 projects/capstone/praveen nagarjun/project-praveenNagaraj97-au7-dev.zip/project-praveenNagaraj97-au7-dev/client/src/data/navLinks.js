// nav Items
export const navItems = [
  {
    name: "Help",
    icon: "help",
    route: "/help",
  },
  // {
  //   name: "Developers",
  //   icon: "code",
  //   route: "/devs",
  // },
  {
    name: "Orders",
    icon: "unordered list",
    route: "/orders",
  },
];
