export { default as loginRoute } from "./loginRoute";
export { default as signupRoute } from "./signupRoute";
export { default as profileRoute } from "./profileRoute";
export { default as postRoute } from "./postRoute";
export { default as otherUserRoute } from "./otherUserRoute";
export { default as chatRoute } from "./chatRoute";
