export { default as userController } from "./userController";
export { default as profileController } from "./profileController";
export { default as postController } from "./postController";
export { default as otherUserController } from "./otherUserController";
export { default as chatController } from "./chatController";
