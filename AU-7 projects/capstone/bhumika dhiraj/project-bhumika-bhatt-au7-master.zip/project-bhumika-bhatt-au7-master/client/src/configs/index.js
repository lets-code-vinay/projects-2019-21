export { default as WEB_URL } from "./webUrl";
