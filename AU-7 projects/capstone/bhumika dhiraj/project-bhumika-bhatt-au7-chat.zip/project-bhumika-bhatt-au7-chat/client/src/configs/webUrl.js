export default {
  AUTHENTICATION: "/authentication",
  HOMEPAGE: "/",
  SETTINGS: "/settings",
  PROFILE: "/profile",
  CREATE: "/create",
  USER_PROFILE: "/profile/:userId",
};
