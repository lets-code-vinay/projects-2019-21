export const LOGIN = "LOGIN";
export const SIGNUP = "SIGNUP";
export const GET_POST = "GET_POST";
export const GET_MY_POST = "GET_MY_POST";
export const UPDATE_POST = "UPDATE_POST";
export const DELETE_POST = "DELETE_POST";
