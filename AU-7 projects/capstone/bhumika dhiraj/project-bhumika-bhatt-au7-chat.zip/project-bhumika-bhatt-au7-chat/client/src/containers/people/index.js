import React, { Component } from "react";

import { PeopleList } from "../../components";

class People extends Component {
  render() {
    return <PeopleList />;
  }
}

export default People;
