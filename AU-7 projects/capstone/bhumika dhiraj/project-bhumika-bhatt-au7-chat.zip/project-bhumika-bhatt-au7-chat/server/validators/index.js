export { default as signupValidator } from "./signupValidator";
