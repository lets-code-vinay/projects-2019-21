import React, { Fragment } from "react";

const About = () => {
  return (
    <Fragment>
      <h1>About Page</h1>
    </Fragment>
  );
};

export default About;
