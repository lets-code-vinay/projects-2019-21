import {createStore,combineReducers,applyMiddleware} from 'redux'

import thunk from 'redux-thunk';
import {composeWithDevTools} from 'redux-devtools-extension'

//reducers
import {productListReducer,productDetailsReducer,productdeleteReducer,productCreateReducer,productDetailsEditReducer,productUpdateReducer} from './reducers/productReducers' 
import {cartReducer} from './reducers/cartReducer'
import {userLoginReducer,userRegisterReducer,userDetailsReducer,userUpdateProfileReducer,userListReducer,userDeleteReducer} from './reducers/userReducers'
import {orderCreateReducer,orderDetialsReducer,orderPayReducer,orderListMyReducer,orderListReducer} from './reducers/orderReducers'
// productDetailsEditReducer added to clear state conflicts

const reducer= combineReducers({productList:productListReducer,
                                productDetails:productDetailsReducer,
                                productDelete:productdeleteReducer,
                                productCreate:productCreateReducer,
                                productDetailsEdit:productDetailsEditReducer,
                                productUpdate:productUpdateReducer,
                                cart:cartReducer,
                                 userLogin :userLoginReducer,
                                userRegister: userRegisterReducer,
                            userDetails:userDetailsReducer,
                            userUpdateProfile:userUpdateProfileReducer,
                            userList:userListReducer,
                            userDelete:userDeleteReducer,
                            orderCreate :orderCreateReducer,
                            orderDetails:orderDetialsReducer,
                            orderPay:orderPayReducer,
                            orderListMy:orderListMyReducer,
                            orderList:orderListReducer
                        })

const cartItemsFromStorage =localStorage.getItem('cartItems') ? JSON.parse(localStorage.getItem('cartItems')) :[]                        
const userInfoFromStorage =localStorage.getItem('userInfo') ? JSON.parse(localStorage.getItem('userInfo')) :null                 

const shippingAddressFromStorage =localStorage.getItem('shippingAddress') ? JSON.parse(localStorage.getItem('shippingAddress')) :{}

//paymentMethod 
const paymentMethodFromStorage =localStorage.getItem('paymentMethod') ? JSON.parse(localStorage.getItem('paymentMethod')) :" "

const initialState={
    cart :{cartItems:cartItemsFromStorage,shippingAddress:shippingAddressFromStorage,paymentMethod:paymentMethodFromStorage},
   userLogin: {userInfo:userInfoFromStorage},
   
}


const middleware=[thunk]


const store= createStore(reducer,initialState,composeWithDevTools(applyMiddleware(...middleware)))



export default store