Capstone Project

# MERN Stack - The Mobile Store
> The Mobile Store website built with the MERN stack with React, pure CSS for style


 Run the client & server with concurrently
 `npm run dev`

Run the Express server only
`npm run server`

Run the React client only
`npm run client`



