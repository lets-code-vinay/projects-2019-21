module.exports={
    MONGO_URL:process.env.MONGO_URL,
    SENDGRID_API:process.env.SENDGRID_API,
    CLIENT_URL:process.env. CLIENT_URL
}