import React, { Component } from 'react'
import Logout from '../Components/Logout.js'

const Admin = () => {

   
    return (
       <Logout></Logout>
    )
}

export default Admin