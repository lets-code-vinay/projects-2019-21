import React from 'react';

import './App.css';
import Home from './ShoppingCart/Components/Home'

function App() {
  return (
        <div>
         <Home></Home>
        </div>
  );
}

export default App;
