var express = require("express");
const mongoose = require("mongoose");
var route = express.Router();
var Post = require("../models/post");
var User = require("../models/user");
var requireLogin = require("../middleware/requireLogin");


//Getting inside other user

route.get("/user/:id", requireLogin, (req, res) => {
  User.findOne({ _id: req.params.id })
    .select("-password")
    .then((user) => {
      Post.find({ postedBy: req.params.id })
        .populate("postedBy", "_id name")
        .exec((err, posts) => {
          if (err) {
            return res.status(422).json({ error: err });
          }
          res.json({ user, posts });
        });
    })
    .catch((err) => {
      return res.status(404).json({ error: "user not found" });
    });
});


//FOLLOW


route.put("/follow",requireLogin, (req, res) => {
  User.findByIdAndUpdate(
    req.body.followId,
    {
      $push: { followers: req.user._id },
    },
    { new: true },
    (err, result) => {
      if (err) {
        return res.status(422).json({ error: err });
      }
      User.findByIdAndUpdate(
        req.user._id,
        {
          $push: { following: req.body.followId },
        },
        { new: true }
      ).select("-password")
        .then((result) => {
          res.json(result);
        })
        .catch((err) => {
          return res.status(422).json({ error: err });
        });
    }
  );
});


//UNFOLLOW
route.put("/unfollow",requireLogin, (req, res) => {
    User.findByIdAndUpdate(
      req.body.unfollowId,
      {
        $pull: { followers: req.user._id },
      },
      { new: true },
      (err, result) => {
        if (err) {
          return res.status(422).json({ error: err });
        }
        User.findByIdAndUpdate(
          req.user._id,
          {
            $pull: { following: req.body.followId },
          },
          { new: true }
        ).select("-password")
          .then((result) => {
            res.json(result);
          })
          .catch((err) => {
            return res.status(422).json({ error: err });
          });
      }
    );
  });


  //UPDATE_PIC

  route.put("/updatepic",requireLogin,(req,res)=>
  {
    User.findByIdAndUpdate(req.user._id,{$set:{pic:req.body.pic}},{new:true}
      ,(err,result)=>
    {
     
      if (err)
      {
        return res.status(422).json({error:"PIC CANOT POST"})
      }
      res.json(result)
    })
  })

module.exports = route;
