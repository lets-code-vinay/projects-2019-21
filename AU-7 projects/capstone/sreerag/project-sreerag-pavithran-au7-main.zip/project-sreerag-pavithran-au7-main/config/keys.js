module.exports = {
  mongoURI: "mongodb://localhost/devconnect", // Insert your MongoDB connection URI here
  /* Example DB connection 
    "mongodb://user_name:password@ds153752.mlab.com:53752/devconnector"
    
    */
  secretOrKey: "s54d35s4d35s4d35s4d654sd654s5d4" // Add your secret string or key here
};
