# Dev-Connector

## Still under construction!

### How to get it up and running

```
module.exports = {
  mongoURI: 'YOUR_OWN_MONGO_URI',
  secretOrKey: 'YOUR_OWN_SECRET'
};
```

A platform where developers can interact with other developers by creating posts with tags and commenting on these posts . In Future, They can stay updated with the latest trends in each tag just by clicking on it.They can also create posts and comment on posts to earn points.They can use these points to create sponsored posts.They can also chat in multiple channels .
Specifications
• Registration
Sign Up/ Login
Forget/Reset Password
• Developer Profile
Create and manage Profile
GitHub Repos list 
Education History
Experience History
Social Links
Skill Sets
• HomePage/User actions 
View Latest Posts
View Posts by hashtag similar to twitter(Future)
Comment on individual posts 
Like Individual posts
Create Post
View other users profile
Current tech news (Future)


Tech stack
1. Node.Js
2. Express.Js
3. Mongodb
4. Html
5. Css/Scss
6. Bootstrap/Reactstrap
7. React.Js
8. Redux
9. Json Web Tokens
10. Passport Js
11. Bcrypt
12. Axios
Future Improvements
	• Chat Section
A universal chat for logged in users
They can join different channels
Experience Tags based on xp points

• Insights 
View your stats on commented posts
View your stats on created posts
Sponsored post Insights

